1. The general project context will be placed here.
